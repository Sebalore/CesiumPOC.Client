/// <reference path="globals/babel-core/index.d.ts" />
/// <reference path="globals/lodash/index.d.ts" />
/// <reference path="globals/react-dom/index.d.ts" />
/// <reference path="globals/react/index.d.ts" />
/// <reference path="globals/rimraf/index.d.ts" />
/// <reference path="globals/webpack/index.d.ts" />
